# guid
Human friendly GUID/UUID library
